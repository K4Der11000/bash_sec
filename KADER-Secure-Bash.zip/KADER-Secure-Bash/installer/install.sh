#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BASE="$HOME/.local/opt/kader-secure-bash"
BIN="$HOME/.local/bin"
mkdir -p "$BASE" "$BIN"
python3 -m venv "$BASE/venv"
"$BASE/venv/bin/pip" install --upgrade pip
"$BASE/venv/bin/pip" install -r "$ROOT/requirements.txt"
install -m 0644 "$ROOT/src/kader_secure_bash.py" "$BASE/kader_secure_bash.py"
cat > "$BIN/kader-secure-bash" <<EOF
#!/usr/bin/env bash
exec "$BASE/venv/bin/python" "$BASE/kader_secure_bash.py" "\${@}"
EOF
cat > "$BIN/kader-vault" <<EOF
#!/usr/bin/env bash
exec "$BASE/venv/bin/python" "$BASE/kader_secure_bash.py" vault "\${@}"
EOF
chmod 0755 "$BIN/kader-secure-bash" "$BIN/kader-vault"
install -m 0644 "$ROOT/README.md" "$BASE/README.md"
cat > "$BASE/uninstall.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
rm -f "$BIN/kader-secure-bash" "$BIN/kader-vault"
rm -rf "$BASE"
echo "Removed user-level KADER Secure Bash application."
echo "Vault data in ~/.config/kader-secure-bash was preserved."
EOF
chmod 0755 "$BASE/uninstall.sh"
echo "Installed for current user only."
echo "Add ~/.local/bin to PATH if needed, then run: kader-secure-bash setup"
