# Manual smoke tests

1. Run `kader-secure-bash setup` and configure a password of at least 12 characters.
2. Run `kader-vault add "printf 'hello\\n'"`.
3. Run `kader-vault list`; confirm it asks for the password and shows the record.
4. Enter a wrong password; confirm no record is displayed.
5. Run `kader-secure-bash`; authenticate and confirm an interactive Bash prompt opens.
6. Confirm `/bin/bash` was not modified by the installer.

These tests validate the safe MVP, not a security certification.
