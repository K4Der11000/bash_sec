#!/usr/bin/env python3
"""User-level password gate and encrypted command-record vault. Never executes vault entries."""
from __future__ import annotations
import argparse
import base64
import getpass
import json
import os
import secrets
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    print("Missing dependencies. Run installer/install.sh first.", file=sys.stderr)
    raise SystemExit(2)

APP_DIR = Path.home() / ".config" / "kader-secure-bash"
HASH_FILE = APP_DIR / "password.hash"
VAULT_FILE = APP_DIR / "commands.vault"
SALT_FILE = APP_DIR / "kdf.salt"
PH = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2, hash_len=32, salt_len=16)

def secure_dir() -> None:
    APP_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        APP_DIR.chmod(0o700)
    except OSError:
        pass

def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    try:
        path.chmod(mode)
    except OSError:
        pass

def setup() -> None:
    secure_dir()
    if HASH_FILE.exists():
        print("Already configured. Refusing to overwrite existing credentials.")
        return
    p1 = getpass.getpass("Create Vault password: ")
    p2 = getpass.getpass("Confirm password: ")
    if len(p1) < 12:
        print("Use at least 12 characters.")
        return
    if p1 != p2:
        print("Passwords do not match.")
        return
    salt = secrets.token_bytes(16)
    atomic_write(HASH_FILE, PH.hash(p1).encode())
    atomic_write(SALT_FILE, base64.b64encode(salt))
    print(f"Setup complete. Configuration: {APP_DIR}")

def authenticate() -> str | None:
    if not HASH_FILE.exists() or not SALT_FILE.exists():
        print("Not configured. Run: kader-secure-bash setup", file=sys.stderr)
        return None
    for attempt in range(1, 4):
        password = getpass.getpass("KADER Secure Bash password: ")
        try:
            PH.verify(HASH_FILE.read_text(), password)
            if PH.check_needs_rehash(HASH_FILE.read_text()):
                atomic_write(HASH_FILE, PH.hash(password).encode())
            return password
        except (VerifyMismatchError, VerificationError):
            print(f"Authentication failed ({attempt}/3).", file=sys.stderr)
    print("Too many failed attempts.", file=sys.stderr)
    return None

def derive_key(password: str) -> bytes:
    salt = base64.b64decode(SALT_FILE.read_bytes())
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    kdf = Scrypt(salt=salt, length=32, n=2**15, r=8, p=1)
    return kdf.derive(password.encode("utf-8"))

def add_record(password: str, command: str) -> None:
    if not command.strip():
        print("Empty command record refused.")
        return
    key = derive_key(password)
    nonce = secrets.token_bytes(12)
    payload = {
        "id": "CMD-" + secrets.token_hex(4).upper(),
        "command": command,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "note": "Stored as a record only; never executed by the Vault."
    }
    ciphertext = AESGCM(key).encrypt(nonce, json.dumps(payload).encode(), b"KADER-COMMAND-VAULT-v1")
    record = {
        "v": 1,
        "nonce": base64.b64encode(nonce).decode(),
        "ciphertext": base64.b64encode(ciphertext).decode()
    }
    secure_dir()
    with VAULT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, separators=(",", ":")) + "\n")
    try:
        VAULT_FILE.chmod(0o600)
    except OSError:
        pass
    print(f"Saved encrypted record: {payload['id']}")

def list_records(password: str) -> None:
    if not VAULT_FILE.exists():
        print("Vault is empty.")
        return
    key = derive_key(password)
    count = 0
    try:
        for line in VAULT_FILE.read_text().splitlines():
            if not line.strip():
                continue
            item = json.loads(line)
            nonce = base64.b64decode(item["nonce"])
            ciphertext = base64.b64decode(item["ciphertext"])
            plain = AESGCM(key).decrypt(nonce, ciphertext, b"KADER-COMMAND-VAULT-v1")
            record = json.loads(plain)
            count += 1
            print(f"\n{record['id']}  |  {record['created_at']}")
            print(f"Original command: {record['command']}")
            print("Encryption: AES-256-GCM (authenticated)")
    except Exception:
        print("Vault integrity/decryption check failed. No records displayed.", file=sys.stderr)
        raise SystemExit(3)
    if count == 0:
        print("Vault is empty.")

def launch_bash(password: str) -> None:
    # Authentication is complete; the Vault does not inspect or rewrite shell input.
    bash = shutil.which("bash")
    if not bash:
        print("Bash executable not found.", file=sys.stderr)
        raise SystemExit(4)
    env = os.environ.copy()
    env["KADER_SECURE_BASH_SESSION"] = "authenticated"
    os.execve(bash, [bash, "--noprofile", "--norc", "-i"], env)

def main() -> None:
    parser = argparse.ArgumentParser(prog="kader-secure-bash")
    sub = parser.add_subparsers(dest="action")
    sub.add_parser("setup", help="initialize password and encrypted Vault")
    sub.add_parser("session", help="authenticate and start interactive Bash")
    vault = sub.add_parser("vault", help="manage encrypted command records")
    vault_sub = vault.add_subparsers(dest="vault_action", required=True)
    add = vault_sub.add_parser("add", help="store a command as an encrypted record; does not execute it")
    add.add_argument("command", help="command text to store")
    vault_sub.add_parser("list", help="authenticate and display decrypted records")
    args = parser.parse_args()

    if args.action == "setup":
        setup()
    elif args.action == "session" or args.action is None:
        password = authenticate()
        if password is not None:
            launch_bash(password)
        raise SystemExit(1)
    elif args.action == "vault":
        password = authenticate()
        if password is None:
            raise SystemExit(1)
        if args.vault_action == "add":
            add_record(password, args.command)
        elif args.vault_action == "list":
            list_records(password)

if __name__ == "__main__":
    main()
