# KADER Secure Bash — Safe MVP

A user-level password gate for starting an interactive Bash session, plus an encrypted
Command Vault for records that the user explicitly chooses to save.

## Important safety boundary

This project **does not replace, rename, disable, or modify `/bin/bash`**. It does not
install itself as the system shell and does not intercept or rewrite arbitrary commands.
Replacing the system Bash can break boot, maintenance tools, scripts, and recovery.

The launcher authenticates, then starts the system Bash as a child process. Vault records
are explicitly added with `kader-vault add`; commands are **stored as records only and
are never executed by the Vault**.

## Requirements

- Linux (tested design target: Kali Linux)
- Python 3.10+
- Bash
- `pip`

## Install (user-level)

```bash
chmod +x installer/install.sh
./installer/install.sh
```

The installer creates `~/.local/opt/kader-secure-bash/venv`, installs dependencies in
that virtual environment, and creates launchers in `~/.local/bin`. It does not use sudo.

Ensure `~/.local/bin` is in your PATH:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

## First-time setup

```bash
kader-secure-bash setup
```

Choose a strong Vault password. Password verification uses Argon2id. Vault entries are
encrypted using AES-256-GCM with a key derived from the password using scrypt.

## Start a protected Bash session

```bash
kader-secure-bash
```

After successful authentication, the program replaces itself with an interactive Bash
process. The password is requested once per launch/session.

## Command Vault

Add a record (this does not run the command):

```bash
kader-vault add "ls -la"
kader-vault add "git status"
```

List records:

```bash
kader-vault list
```

The Vault prompts for the password before displaying records.

## Uninstall

```bash
~/.local/opt/kader-secure-bash/uninstall.sh
```

This removes only the user-level installation. It does not remove your Vault data unless
you separately delete `~/.config/kader-secure-bash`.

## Security notes

- Protect your Linux account. A user with access to your account can alter user-level files.
- Keep a secure backup of `~/.config/kader-secure-bash`.
- If you forget the password, encrypted Vault records cannot be recovered.
- This MVP does not provide PAM integration, tamper-proof audit logging, or automatic
  capture of every shell command.
