#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREFIX="${PREFIX:-/usr/local}"
DEST="$PREFIX/bin"
SBIN="$PREFIX/sbin"
CONF_DIR="/etc/kader-secure-bash"
LOG="$ROOT/logs/install.log"

if [[ $EUID -ne 0 ]]; then
  echo "Run with: sudo $0"
  exit 1
fi
command -v gcc >/dev/null || { echo "gcc is required"; exit 1; }
command -v openssl >/dev/null || { echo "openssl is required"; exit 1; }
command -v python3 >/dev/null || { echo "python3 is required"; exit 1; }

install -d -m 0755 "$DEST" "$SBIN" "$CONF_DIR"
if [[ ! -f "$CONF_DIR/users.conf" ]]; then
  cat > "$CONF_DIR/users.conf" <<'EOF'
# Root-managed KADER-Secure-Bash launch policy
# Values: secure | original
# This controls the KADER launcher only; it is not an OS-wide Bash ban.
default=secure
EOF
fi
chown root:root "$CONF_DIR/users.conf"
chmod 0600 "$CONF_DIR/users.conf"

if [[ ! -f "$CONF_DIR/security.conf" ]]; then
  read -rsp "Set KADER-Secure-Bash password: " PW; echo
  [[ -n "$PW" ]] || { echo "Password cannot be empty"; exit 1; }
  HASH="$(printf '%s' "$PW" | openssl passwd -6 -stdin)"
  unset PW
  printf 'password_hash=%s\n' "$HASH" > "$CONF_DIR/security.conf"
  chmod 0600 "$CONF_DIR/security.conf"
fi

gcc -Wall -Wextra -O2 "$ROOT/src/secure_bash.c" "$ROOT/src/auth.c" -lcrypt -o "$DEST/kader-secure-bash"
install -m 0750 -o root -g root "$ROOT/src/manage_users.py" "$SBIN/kader-shell-manager"
chmod 0755 "$DEST/kader-secure-bash"
printf '[%s] Installed %s\n' "$(date -Is)" "$DEST/kader-secure-bash" | tee -a "$LOG"
echo "Installed. Start with: kader-secure-bash"
echo "Manage per-user policy with: sudo kader-shell-manager"
echo "Default policy is Secure Bash. Original Bash can be enabled per account."
echo "Safety: /bin/bash, /etc/passwd and account login shells are not modified."
