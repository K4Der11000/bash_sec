#!/usr/bin/env python3
import http.server,json,os,pwd,secrets,tempfile,webbrowser
from pathlib import Path
from datetime import datetime
CONF=Path('/etc/kader-secure-bash'); POLICY=CONF/'users.conf'; LOG=CONF/'admin.log'; TOKEN=CONF/'ui.token'
HOST,PORT='127.0.0.1',8765
def root():
    if os.geteuid()!=0: raise SystemExit('Run with sudo: kader-secure-bash-ui')
def gettoken():
    CONF.mkdir(mode=0o755,parents=True,exist_ok=True)
    if TOKEN.exists() and TOKEN.read_text().strip(): return TOKEN.read_text().strip()
    t=secrets.token_urlsafe(32);TOKEN.write_text(t+'\\n');os.chown(TOKEN,0,0);os.chmod(TOKEN,0o600);return t
def load():
    d={'default':'secure'}
    if POLICY.exists():
        for line in POLICY.read_text().splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k,v=line.strip().split('=',1)
                if v in ('secure','original'):d[k]=v
    return d
def save(d):
    lines=['# Root managed KADER launcher policy','default='+d.get('default','secure')]+[f'{k}={d[k]}' for k in sorted(d) if k!='default']
    fd,tmp=tempfile.mkstemp(dir=str(CONF),prefix='.users.')
    with os.fdopen(fd,'w') as f:f.write('\\n'.join(lines)+'\\n');f.flush();os.fsync(f.fileno())
    os.chown(tmp,0,0);os.chmod(tmp,0o600);os.replace(tmp,POLICY)
def audit(s):
    with LOG.open('a') as f:f.write(f'[{datetime.now().astimezone().isoformat(timespec="seconds")}] {s}\\n')
    os.chown(LOG,0,0);os.chmod(LOG,0o600)
def rows():
    p=load();return [{'name':u.pw_name,'uid':u.pw_uid,'kind':'root' if u.pw_uid==0 else ('system/service' if u.pw_uid<1000 else 'regular'),'policy':p.get(u.pw_name,p.get('default','secure'))} for u in sorted(pwd.getpwall(),key=lambda x:(x.pw_uid!=0,x.pw_uid,x.pw_name))]
class H(http.server.BaseHTTPRequestHandler):
    def sendj(self,x,code=200):
        b=json.dumps(x).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def auth(self):return secrets.compare_digest(self.headers.get('X-KADER-Token',''),self.server.token)
    def do_GET(self):
        path=self.path.split('?',1)[0]
        if path=='/':
            b=(Path(__file__).with_name('admin.html')).read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
        if not self.auth():return self.send_error(403)
        if path=='/api/users':return self.sendj({'users':rows(),'default':load().get('default','secure')})
        if path=='/api/logs':return self.sendj({'logs':LOG.read_text()[-12000:] if LOG.exists() else ''})
        self.send_error(404)
    def do_POST(self):
        if not self.auth():return self.send_error(403)
        if self.path!='/api/policy':return self.send_error(404)
        try:d=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
        except Exception:return self.send_error(400)
        p=load()
        if 'user' in d:
            n=d['user'];v=d.get('policy')
            try:pwd.getpwnam(n)
            except KeyError:return self.send_error(400,'Unknown user')
            if v not in ('secure','original'):return self.send_error(400)
            p[n]=v;audit(f'{n} policy -> {v}')
        elif d.get('default') in ('secure','original'):
            p['default']=d['default'];audit('default policy -> '+p['default'])
        else:return self.send_error(400)
        save(p);return self.sendj({'ok':True})
    def log_message(self,*a):pass
def main():
    root();t=gettoken();s=http.server.ThreadingHTTPServer((HOST,PORT),H);s.token=t
    url=f'http://{HOST}:{PORT}/#{t}';print('KADER dashboard:',url);webbrowser.open(url)
    try:s.serve_forever()
    except KeyboardInterrupt:pass
    finally:s.server_close()
if __name__=='__main__':main()
