#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <crypt.h>

static int read_hash(const char *path, char *out, size_t cap) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    char line[2048];
    int found = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "password_hash=", 14) == 0) {
            char *v = line + 14;
            v[strcspn(v, "\r\n")] = '\0';
            if (strlen(v) < cap) {
                strcpy(out, v);
                found = 1;
            }
            break;
        }
    }
    fclose(f);
    return found ? 0 : -1;
}

int authenticate(const char *config_path) {
    char hash[1024] = {0};
    if (read_hash(config_path, hash, sizeof(hash)) != 0) {
        fprintf(stderr, "KADER-Secure-Bash: password hash missing in %s\n", config_path);
        return 0;
    }

    for (int attempt = 1; attempt <= 3; ++attempt) {
        char *password = getpass("KADER-Secure-Bash password: ");
        if (!password) return 0;

        char *computed = crypt(password, hash);
        int ok = computed && strcmp(computed, hash) == 0;
        memset(password, 0, strlen(password));
        if (ok) {
            puts("[+] Authentication successful.");
            return 1;
        }
        fprintf(stderr, "[-] Authentication failed (%d/3).\n", attempt);
    }
    return 0;
}
