#!/usr/bin/env python3
"""Root-only per-user policy manager for KADER-Secure-Bash."""
import os
import pwd
import tempfile
from pathlib import Path

CONFIG = Path("/etc/kader-secure-bash/users.conf")
MIN_UID = 0

def require_root():
    if os.geteuid() != 0:
        raise SystemExit("Run as root: sudo kader-shell-manager")

def load_config():
    settings = {"default": "secure"}
    if CONFIG.exists():
        for raw in CONFIG.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            name, value = line.split("=", 1)
            if value in ("secure", "original"):
                settings[name] = value
    return settings

def save_config(settings):
    CONFIG.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    lines = [
        "# Root-managed KADER-Secure-Bash launch policy",
        "# Values: secure | original",
        "# This controls the KADER launcher only; it is not an OS-wide Bash ban.",
        f"default={settings.get('default', 'secure')}",
    ]
    for name in sorted(k for k in settings if k != "default"):
        lines.append(f"{name}={settings[name]}")
    fd, tmp = tempfile.mkstemp(prefix=".users.", dir=str(CONFIG.parent), text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.chown(tmp, 0, 0)
        os.chmod(tmp, 0o600)
        os.replace(tmp, CONFIG)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

def users():
    result = []
    for p in pwd.getpwall():
        # Show all accounts as requested; system/service accounts are labelled.
        result.append(p)
    return sorted(result, key=lambda p: (p.pw_uid != 0, p.pw_uid, p.pw_name))

def main():
    require_root()
    settings = load_config()
    while True:
        print("\nKADER11000 Secure Bash — User Shell Manager")
        print("Default policy:", settings.get("default", "secure"))
        print("-" * 68)
        print(f"{'No.':<5}{'Username':<22}{'UID':<9}{'Policy':<13}{'Account type'}")
        for i, p in enumerate(users(), 1):
            policy = settings.get(p.pw_name, settings.get("default", "secure"))
            kind = "system/service" if p.pw_uid < 1000 and p.pw_uid != 0 else ("root" if p.pw_uid == 0 else "regular")
            print(f"{i:<5}{p.pw_name:<22}{p.pw_uid:<9}{policy:<13}{kind}")
        print("\n[E] Enable original Bash for a user")
        print("[D] Disable original Bash (use Secure Bash launcher)")
        print("[A] Set default policy")
        print("[Q] Quit")
        choice = input("Select: ").strip().lower()
        if choice == "q":
            break
        if choice in ("e", "d"):
            name = input("Exact username: ").strip()
            try:
                pwd.getpwnam(name)
            except KeyError:
                print("Unknown account.")
                continue
            settings[name] = "original" if choice == "e" else "secure"
            save_config(settings)
            print(f"Saved: {name} -> {settings[name]}. Applies to new KADER launcher sessions.")
        elif choice == "a":
            value = input("Default [secure/original]: ").strip().lower()
            if value not in ("secure", "original"):
                print("Invalid value.")
                continue
            settings["default"] = value
            save_config(settings)
            print("Default policy saved.")
        else:
            print("Unknown selection.")

if __name__ == "__main__":
    main()
