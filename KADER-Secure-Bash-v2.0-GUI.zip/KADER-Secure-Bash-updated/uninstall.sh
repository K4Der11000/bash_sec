#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with: sudo $0"; exit 1; fi
rm -f /usr/local/bin/kader-secure-bash /usr/local/sbin/kader-shell-manager /usr/local/sbin/kader-secure-bash-ui
rm -rf /etc/kader-secure-bash
echo "KADER-Secure-Bash removed. /bin/bash and user login-shell records were not modified."
