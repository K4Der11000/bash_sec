# KADER-Secure-Bash

A learning-oriented restricted command launcher with a root-managed, per-account
choice between the system Bash login shell and the restricted KADER launcher.

## Per-user original Bash policy

Run the manager as root:

```bash
sudo kader-shell-manager
```

It lists local accounts and lets an administrator choose:
- **Enable original Bash**: when that account starts `kader-secure-bash`, it is
  handed off to `/bin/bash --login`.
- **Disable original Bash**: the KADER restricted command launcher is used.
- **Default policy**: controls accounts without an explicit entry. The safe
  default is `secure`.

The policy is stored in `/etc/kader-secure-bash/users.conf`, owned by root and
mode `0600`. Changes apply to new KADER launcher sessions.

## Important security limitation

This policy controls only sessions started through `kader-secure-bash`. It
does **not** prevent a user from running `/bin/bash` directly if the operating
system otherwise permits it. It is not a system-wide Bash disable switch and
must not be represented as one. Do not chmod, delete, overwrite, or replace
`/bin/bash`; doing so can break system tools and recovery.

The current restricted mode is still a small allowlist launcher, not a full
Bash implementation and not a strong sandbox. It does not isolate filesystem,
network, or kernel access. Do not set it as a production login shell or use it
as the only security boundary. For real isolation, use dedicated unprivileged
accounts and OS-level controls such as containers, namespaces, MAC policy, and
seccomp, designed and tested for the target system.

## Install (Kali Linux)

Requirements: `gcc`, `python3`, `openssl`, and system `libcrypt` development
files.

```bash
sudo ./installer/install.sh
kader-secure-bash
sudo kader-shell-manager
```

The installer preserves existing password configuration and policy files. It
does not modify `/bin/bash`, `/etc/passwd`, or users' configured login shells.

## Uninstall

```bash
sudo ./uninstall.sh
```

Uninstall removes the installed launcher, manager, and KADER configuration.
It never modifies the system Bash binary or login-shell records.

## Current restricted-mode allowlist

External commands: `ls`, `pwd`, `whoami`, `id`, `date`, `uname`, `clear`.
Built-ins: `echo`, `cd`, `help`, `exit`.

Shell operators, redirection, command substitution, globbing and quoting are
rejected. This is intentionally much smaller than Bash.

\n## Graphical dashboard\n\nRun `sudo kader-secure-bash-ui`. It serves a dashboard on localhost only\n(127.0.0.1:8765), with per-user shell policy controls and an activity log.\nThe command-policy panel is informational in this build because the C launcher\nstill uses a compile-time allowlist; it does not claim to dynamically enforce\nGUI edits. Do not expose the dashboard port to a network.\n