#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with: sudo $0"; exit 1; fi
rm -f /usr/local/bin/kader-secure-bash
rm -rf /etc/kader-secure-bash
echo "KADER-Secure-Bash removed. /bin/bash was never modified."
