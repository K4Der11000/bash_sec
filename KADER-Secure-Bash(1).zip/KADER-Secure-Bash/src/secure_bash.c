#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

int authenticate(const char *config_path);

typedef struct { const char *name; const char *path; } Command;
static const Command commands[] = {
    {"ls", "/bin/ls"}, {"pwd", "/bin/pwd"}, {"whoami", "/usr/bin/whoami"},
    {"id", "/usr/bin/id"}, {"date", "/bin/date"}, {"uname", "/bin/uname"},
    {"clear", "/usr/bin/clear"}
};
static const size_t command_count = sizeof(commands) / sizeof(commands[0]);

static int is_forbidden_syntax(const char *s) {
    /* No shell grammar: chaining, redirects, substitutions, globbing, or quoting. */
    const char *bad = ";|&><`$(){}*?[]'\"\\";
    return strpbrk(s, bad) != NULL;
}

static void help(void) {
    puts("Allowed commands: ls pwd whoami id date uname clear echo cd help exit");
    puts("No pipes, redirects, chaining, substitutions, quotes, or shell expansion.");
    puts("Commands not listed above are rejected.");
}

static int run_external(const char *name, char **argv) {
    for (size_t i = 0; i < command_count; ++i) {
        if (strcmp(name, commands[i].name) == 0) {
            pid_t pid = fork();
            if (pid < 0) { perror("fork"); return -1; }
            if (pid == 0) {
                char *const envp[] = {"PATH=/usr/bin:/bin", "LANG=C", NULL};
                execve(commands[i].path, argv, envp);
                perror("execve");
                _exit(127);
            }
            int status = 0;
            if (waitpid(pid, &status, 0) < 0) perror("waitpid");
            return status;
        }
    }
    fprintf(stderr, "[BLOCKED] Command not allowlisted: %s\n", name);
    return -1;
}

int main(int argc, char **argv) {
    const char *config = argc > 1 ? argv[1] : "/etc/kader-secure-bash/security.conf";
    if (!authenticate(config)) return 1;

    puts("KADER-Secure-Bash | restricted command session");
    puts("Type 'help' for the allowlist. This is a restricted launcher, not a replacement for /bin/bash.");

    char *line = NULL;
    size_t cap = 0;
    while (1) {
        printf("kader-secure> ");
        fflush(stdout);
        ssize_t n = getline(&line, &cap, stdin);
        if (n < 0) break;
        if (n > 2048) { puts("[BLOCKED] Input too long."); continue; }
        line[strcspn(line, "\r\n")] = '\0';
        if (!line[0]) continue;

        if (is_forbidden_syntax(line)) {
            puts("[BLOCKED] Shell operators/expansion/quoting are not supported.");
            continue;
        }

        char *argvv[64] = {0};
        int argc2 = 0;
        char *save = NULL;
        for (char *tok = strtok_r(line, " \t", &save);
             tok && argc2 < 63;
             tok = strtok_r(NULL, " \t", &save)) {
            argvv[argc2++] = tok;
        }
        argvv[argc2] = NULL;
        if (argc2 == 0) continue;

        const char *cmd = argvv[0];
        if (strcmp(cmd, "exit") == 0) break;
        if (strcmp(cmd, "help") == 0) { help(); continue; }
        if (strcmp(cmd, "echo") == 0) {
            for (int i = 1; i < argc2; ++i)
                printf("%s%s", i == 1 ? "" : " ", argvv[i]);
            putchar('\n');
            continue;
        }
        if (strcmp(cmd, "cd") == 0) {
            if (argc2 != 2) { puts("[BLOCKED] Usage: cd DIRECTORY"); continue; }
            if (chdir(argvv[1]) != 0) perror("cd");
            continue;
        }
        run_external(cmd, argvv);
    }
    free(line);
    puts("Secure session closed.");
    return 0;
}
