#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREFIX="${PREFIX:-/usr/local}"
DEST="$PREFIX/bin"
CONF_DIR="/etc/kader-secure-bash"
LOG="$ROOT/logs/install.log"

if [[ $EUID -ne 0 ]]; then
  echo "Run with: sudo $0"
  exit 1
fi
command -v gcc >/dev/null || { echo "gcc is required"; exit 1; }
command -v openssl >/dev/null || { echo "openssl is required"; exit 1; }

install -d -m 0755 "$DEST" "$CONF_DIR"
read -rsp "Set KADER-Secure-Bash password: " PW; echo
[[ -n "$PW" ]] || { echo "Password cannot be empty"; exit 1; }
HASH="$(printf '%s' "$PW" | openssl passwd -6 -stdin)"
unset PW
printf 'password_hash=%s\n' "$HASH" > "$CONF_DIR/security.conf"
chmod 0600 "$CONF_DIR/security.conf"

gcc -Wall -Wextra -O2 "$ROOT/src/secure_bash.c" "$ROOT/src/auth.c" -lcrypt -o "$DEST/kader-secure-bash"
chmod 0755 "$DEST/kader-secure-bash"
printf '[%s] Installed %s\n' "$(date -Is)" "$DEST/kader-secure-bash" | tee -a "$LOG"
echo "Installed. Start with: kader-secure-bash"
echo "Safety: this installer does NOT replace /bin/bash or change your login shell."
