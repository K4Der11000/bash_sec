# KADER-Secure-Bash

A small **restricted command launcher** for learning and defensive testing. It is
not a replacement for Bash and does not claim to provide a system-wide sandbox.

## What it does
- Password authentication using a SHA-512 crypt hash (`openssl passwd -6`).
- Exact command allowlist: `ls`, `pwd`, `whoami`, `id`, `date`, `uname`,
  `clear`, plus the built-ins `echo`, `cd`, `help`, and `exit`.
- Rejects unlisted commands such as `mkdir`, `wget`, and `eval`.
- Rejects shell operators, redirection, command substitution, globbing, and quotes.
- Executes external commands by fixed absolute path with `execve`; it never
  passes input to `/bin/sh` or `/bin/bash`.

## Important limitations
This is a learning prototype, **not a security boundary**. It does not isolate
filesystem access, network access, or kernel interfaces. A permitted command
may still have options with side effects, and users can start other programs
outside this launcher if they have another route to a system shell. For real
containment, run it inside a dedicated unprivileged account/container/VM with
OS-level controls (e.g. namespaces, seccomp, MAC policy) and no access to a
privileged shell. Do not use it as a replacement login shell.

## Build / install (Kali Linux)
```bash
sudo ./installer/install.sh
kader-secure-bash
```
Requirements: `gcc`, `openssl`, and the system `libcrypt` development files.

The installer writes the password hash to `/etc/kader-secure-bash/security.conf`
with mode `0600`, and installs `/usr/local/bin/kader-secure-bash`.

## Uninstall
```bash
sudo ./uninstall.sh
```
The installer never modifies `/bin/bash`, `/etc/passwd`, or your login shell.

## Example
```text
kader-secure> help
kader-secure> pwd
kader-secure> id
kader-secure> wget https://example.invalid/file
[BLOCKED] Command not allowlisted: wget
kader-secure> exit
```

## Project layout
```text
KADER-Secure-Bash/
├── src/auth.c
├── src/secure_bash.c
├── installer/install.sh
├── backup/README.txt
├── config/security.conf
├── logs/install.log
├── uninstall.sh
└── README.md
```
